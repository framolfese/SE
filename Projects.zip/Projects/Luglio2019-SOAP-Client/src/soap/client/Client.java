package soap.client;

import java.util.List;
import soap.server.Movie;

public class Client {

    public static void main(String[] args){
        System.out.println("Richiedo tutti i movies presenti nel db....");
        List<Movie> movies = getMovies();
        
        for(Movie movie:movies){
            System.out.println(String.format("Movie id: %s, title: %s, year: %s, directorID: %s,\nDirector id: %s, name: %s, yearOfBirth: %s\n",
            movie.getID(), movie.getTitle(), movie.getYear(), movie.getDirectorID(), movie.getDirector().getId(), movie.getDirector().getName(), movie.getDirector().getYearOfBirth()));
        }
        
        System.out.println("Richiedo movie con id 1....");
        System.out.println(getDetailOfAMovie(1));
        
        System.out.println("Richiedo movie con id 4....");
        System.out.println(getDetailOfAMovie(4));
        
    }

    private static String getDetailOfAMovie(int arg0) {
        soap.server.WSImplService service = new soap.server.WSImplService();
        soap.server.WSInterface port = service.getWSImplPort();
        return port.getDetailOfAMovie(arg0);
    }

    private static java.util.List<soap.server.Movie> getMovies() {
        soap.server.WSImplService service = new soap.server.WSImplService();
        soap.server.WSInterface port = service.getWSImplPort();
        return port.getMovies();
    }
}
