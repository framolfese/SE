package soap.server;

import javax.xml.ws.Endpoint;

public class Server {
    public static void main(String args[]) throws InterruptedException {
        Professor.insertProfessor(new Professor("Camil", "Demetrescu", "PFP"));
        Professor.insertProfessor(new Professor("Fabrizio", "D'Amore", "CNS"));
        Professor.insertProfessor(new Professor("Maurizio", "Lenzerini", "DM"));
        Professor.insertProfessor(new Professor("Riccardo", "Rosati", "KRST"));
        Professor.insertProfessor(new Professor("Angelo", "Spognardi", "BOH"));
        Professor.insertProfessor(new Professor("Massimo", "Mecella", "SE"));
        Professor.insertProfessor(new Professor("Luigi Vincenzo", "Mancini", "BOH2"));
        
        WSImpl implementor = new WSImpl();
        String address = "http://localhost:8080/WSInterface";
        Endpoint.publish(address, implementor);
        System.out.println("Server ready...");
    }
}
