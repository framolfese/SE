package soap.server;

import javax.jws.WebService;

@WebService
public interface WSInterface {
    
    public String getBookDetails(int bookId);
    public String getEstimatedDate(int bookId, String seller);
}
