package client;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Scanner;
import javax.xml.bind.JAXB;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class Client {
    
    private static final String BASE_URL = "http://localhost:8080/books/";
    private static CloseableHttpClient client;

    public static void main(String[] args) throws IOException{
        client = HttpClients.createDefault();

        while(true){
            Scanner scanner = new Scanner(System.in);
            System.out.println("Choose a command in the following list: [--list, --details, --date, --exit]");
            String command = scanner.next();
            if(command.equals("--list")){
                System.out.println("Getting all books along with their details");
                Books books = getAllBooks();
                for (int i = 0; i < books.getBooks().size(); i++) {
                    Book b = books.getBooks().get(i);
                    String details = getBookDetails(b.getId());
                    System.out.println(b + " " + details);
                }
            }
            else if(command.equals("--details")){
                System.out.println("Choose a book id");
                String id = scanner.next();
                System.out.println("Getting the chosen book along with its details");
                Book b1 = getBook(Integer.parseInt(id));
                String details = getBookDetails(b1.getId());
                System.out.println(b1 + " " + details);
            }
            else if(command.equals("--date")){
                System.out.println("Choose a book id:");
                String id = scanner.next();
                System.out.println("Choose one of its sellers:");
                String seller = scanner.next();
                System.out.println("Getting the estimated date for a given book-seller pair");
                String estimate = getEstimatedDate(Integer.parseInt(id), seller);
                System.out.println(estimate);
            }
            else if(command.equals("--exit")){
                System.out.println("Client shut down");
                client.close();
                scanner.close();
                System.exit(0);
            }
            else{
                System.out.println("Not a valid command");
            }
        }
    }

    private static Books getAllBooks() throws IOException {
      final URL url = new URL(BASE_URL);
      final InputStream input = url.openStream();
      return JAXB.unmarshal(new InputStreamReader(input), Books.class);
    }

    private static Book getBook(int bookId) throws IOException {
      final URL url = new URL(BASE_URL + String.valueOf(bookId));
      final InputStream input = url.openStream();
      return JAXB.unmarshal(new InputStreamReader(input), Book.class);
    }
      
    private static String getBookDetails(int bookId){
        soap.server.WSImplService service = new soap.server.WSImplService();
        soap.server.WSInterface port = service.getWSImplPort();
        String result = port.getBookDetails(bookId);
        return result;
    }
    
    private static String getEstimatedDate(int bookId, String seller){
        soap.server.WSImplService service = new soap.server.WSImplService();
        soap.server.WSInterface port = service.getWSImplPort();
        String result = port.getEstimatedDate(bookId, seller);
        return result;
    }
}
