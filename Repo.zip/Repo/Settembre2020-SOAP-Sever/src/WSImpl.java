package soap.server;

import javax.jws.WebService;

@WebService(endpointInterface = "soap.server.WSInterface")
public class WSImpl implements WSInterface{

    @Override
    public Professor getDetails(String id) {
        return Professor.getProfessor(id);
    }
    
}
