package soap.server;

import javax.jws.WebService;

@WebService
public interface WSInterface {
    
    public Professor getDetails(String id);
}
