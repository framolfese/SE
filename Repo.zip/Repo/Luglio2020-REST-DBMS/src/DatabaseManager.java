package rest.dbms;

import java.sql.*;

public class DatabaseManager {
    public static void main(String[] args) throws Exception {

        Class.forName("org.sqlite.JDBC");
        Connection conn
                = DriverManager.getConnection("jdbc:sqlite:"+args[0]);
        Statement stat = conn.createStatement();

        if (args[1].equals("create")) {
            stat.executeUpdate("drop table if exists movies;");
            stat.executeUpdate("drop table if exists directors;");
            stat.executeUpdate("create table movies (id, title, year, directorID);");
            stat.executeUpdate("create table directors (id, name, yearOfBirth);");
            PreparedStatement prep = conn.prepareStatement("insert into movies values (?, ?, ?, ?);");
            prep.setString(1, "1");
            prep.setString(2, "Movie1");
            prep.setString(3, "1981");
            prep.setString(4, "1");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setString(1, "2");
            prep.setString(2, "Movie2");
            prep.setString(3, "1982");
            prep.setString(4, "2");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setString(1, "3");
            prep.setString(2, "Movie3");
            prep.setString(3, "1983");
            prep.setString(4, "3");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep = conn.prepareStatement("insert into directors values (?, ?, ?);");
            prep.setString(1, "1");
            prep.setString(2, "Director1");
            prep.setString(3, "1951");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setString(1, "2");
            prep.setString(2, "Director2");
            prep.setString(3, "1952");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setString(1, "3");
            prep.setString(2, "Director3");
            prep.setString(3, "1953");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
        } else {
            ResultSet rs = stat.executeQuery("select * from movies join directors on movies.directorID = directors.id;");
            while (rs.next()) {
                System.out.println("Movie: " + rs.getString("id") + " " + rs.getString("title") + " " + rs.getString("year") + " " + 
                        "with director: " + rs.getString("name") + " " + rs.getString("yearOfBirth"));
            }
            rs.close();
        }
        conn.close();
    }
}
