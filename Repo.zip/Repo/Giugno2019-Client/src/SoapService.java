package client;

import soap.server.Exam;
import soap.server.ExamImplService;
import soap.server.Professor;

public class SoapService {
    
    public static Professor getDetails(String ID){
        ExamImplService is = new ExamImplService();
        Exam port = is.getExamImplPort();
        return port.getDetails(ID);
    }
}