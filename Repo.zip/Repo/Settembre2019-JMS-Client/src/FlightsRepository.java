package jms.client;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FlightsRepository {

    Connection conn;
    
    public void setConnection(String pos) throws SQLException{
        try{
            try{
                Class.forName("org.sqlite.JDBC");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FlightsRepository.class.getName()).log(Level.SEVERE, null, ex);
            }
            conn = DriverManager.getConnection("jdbc:sqlite:" + pos);
        } catch (SQLException ex) {
            Logger.getLogger(FlightsRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
        Statement stat = conn.createStatement();
        stat.executeUpdate("drop table if exists flights;");
        stat.executeUpdate("create table flights (id, landed);");
    }
    
    void insertFlight(String flightId, String landed) {
        PreparedStatement stat = null;
        try{
            stat = conn.prepareStatement("insert into flights values (?, ?);");
            stat.setString(1, flightId);
            stat.setString(2, landed);
            stat.execute();
        } catch (SQLException ex) {
            Logger.getLogger(FlightsRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(String.format("Inserito correttamente (flightId: %s, landed: %s)", flightId, landed));
    }
    
}
