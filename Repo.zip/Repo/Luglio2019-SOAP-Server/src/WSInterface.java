package soap.server;

import java.util.List;
import javax.jws.WebService;

@WebService
public interface WSInterface {
    public String getDetailOfAMovie(int id);
    public List<Movie> getMovies();
}
