package soap.server;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Movie {

    private String ID;
    private String title;
    private String year;
    private String directorID;
    private Director director;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getDirectorID() {
        return directorID;
    }

    public void setDirectorID(String directorID) {
        this.directorID = directorID;
    }

    public Director getDirector() {
        return director;
    }

    public void setDirector(Director director) {
        this.director = director;
    }
    
    @Override
    public String toString(){
        return String.format("Movie id: %s, title: %s, year: %s, directorID: %s,\nDirector id: %s, name: %s, yearOfBirth: %s\n",
                            this.ID, this.title, this.year, this.directorID, this.director.getId(), this.director.getName(), this.director.getYearOfBirth());
    }
}
