package rest.server;

import org.apache.cxf.endpoint.Server;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxrs.lifecycle.SingletonResourceProvider;

public class APIServer {
    
    public static void main(String args[]) throws Exception {

        JAXRSServerFactoryBean factoryBean = new JAXRSServerFactoryBean();
        factoryBean.setResourceClasses(MoviesRepository.class);
        MoviesRepository mr = new MoviesRepository();
        mr.setConnection(args[0]);
        factoryBean.setResourceProvider(new SingletonResourceProvider(mr));
        factoryBean.setAddress("http://localhost:8080/");
        Server server = factoryBean.create();
        System.out.println("Server ready...");
        while (true) {
        }
    }
}
