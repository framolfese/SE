package rest.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

@Path("/movies")
@Produces("text/xml")
public class MoviesRepository {
    
    private Connection conn;
    
    public void setConnection(String pos) {
        try {
            try {
                Class.forName("org.sqlite.JDBC");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(MoviesRepository.class.getName()).log(Level.SEVERE, null, ex);
            }
            conn
                    = DriverManager.getConnection("jdbc:sqlite:"+pos);
        } catch (SQLException ex) {
            Logger.getLogger(MoviesRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @GET
    @Path("{movieId}")
    public Movie getMovie(@PathParam("movieId") int movieId) {
        return findById(movieId);
    }
    
    @GET
    @Path("")
    public Movies getAllMovies(){
        return findAllMovies();
    }
    
    private Movie findById(int movieId){
        PreparedStatement stat = null;
        Movie m = null;
        Director d = null;
        try {
            stat = conn.prepareStatement("select * from movies join directors on movies.directorID = directors.id where movies.id = ?");
            stat.setString(1, String.valueOf(movieId));
        
        ResultSet rs = stat.executeQuery();
        if (rs.next()) {
            m = new Movie();
            d = new Director();
            m.setId(Integer.parseInt(rs.getString("id")));
            m.setTitle(rs.getString("title"));
            m.setYear(rs.getString("year"));
            m.setDirectorName(rs.getString("name"));
            m.setDirectorID(Integer.parseInt(rs.getString("directorID")));
            d.setId(Integer.parseInt(rs.getString("directorID")));
            d.setName(rs.getString("name"));
            d.setYearOfBirth(rs.getString("yearOfBirth"));
            m.setDirector(d);
            
            Logger.getLogger(MoviesRepository.class.getName()).log(Level.INFO, "Accessed : " + m);
        }
        rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(MoviesRepository.class.getName()).log(Level.SEVERE, null, ex);
        }

        return m;
    }
    
    private Movies findAllMovies(){
        PreparedStatement stat = null;
        //creo classe Movies con dentro la lista di tutti i movies
        Movies movies = new Movies();
        //creo la lista vuota e la assegno
        List<Movie> allMovies = new ArrayList<Movie>();
        movies.setMovies(allMovies);
        Movie m = null;
        Director d = null;
        try {
            stat = conn.prepareStatement("select * from movies join directors on movies.directorID = directors.id");
        
        ResultSet rs = stat.executeQuery();
        while (rs.next()) {
            m = new Movie();
            d = new Director();
            m.setId(Integer.parseInt(rs.getString("id")));
            m.setTitle(rs.getString("title"));
            m.setYear(rs.getString("year"));
            m.setDirectorName(rs.getString("name"));
            m.setDirectorID(Integer.parseInt(rs.getString("directorID")));
            d.setId(Integer.parseInt(rs.getString("directorID")));
            d.setName(rs.getString("name"));
            d.setYearOfBirth(rs.getString("yearOfBirth"));
            m.setDirector(d);
            
            //aggiungo ogni movie alla lista dei movies
            movies.getMovies().add(m);
            
            Logger.getLogger(MoviesRepository.class.getName()).log(Level.INFO, "Accessed : " + m);
        }
        rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(MoviesRepository.class.getName()).log(Level.SEVERE, null, ex);
        }

        return movies;
    }
    
}
