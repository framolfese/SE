package client;

public class Client {
    public static void main(String[] args){
        System.out.println("Client start");
        ProfessorListener p = new ProfessorListener();
        p.start();
    }
}
