package rest.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import javax.xml.bind.JAXB;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class Client {
    
    private static final String BASE_URL = "http://localhost:8080/movies/";
    private static CloseableHttpClient client;

    public static void main(String[] args) throws IOException{
        client = HttpClients.createDefault();
        
        //Get all Movies
        Movies movies = getAllMovies();
        for (int i = 0; i < movies.getMovies().size(); i++) {
            Movie m = movies.getMovies().get(i);
            System.out.println(m);
        }
        
        //Get one Movie
        Movie m1 = getMovie(1);
        System.out.println(m1);

        client.close();
    }

      private static Movie getMovie(int movieId) throws IOException {
        final URL url = new URL(BASE_URL+String.valueOf(movieId));
        final InputStream input = url.openStream();
        return JAXB.unmarshal(new InputStreamReader(input), Movie.class);
    }

      private static Movies getAllMovies() throws IOException {
        final URL url = new URL(BASE_URL);
        final InputStream input = url.openStream();
        return JAXB.unmarshal(new InputStreamReader(input), Movies.class);
    }
}
