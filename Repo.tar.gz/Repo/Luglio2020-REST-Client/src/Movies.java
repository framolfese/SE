package rest.client;

import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Movies")
public class Movies {
    
    private List<Movie> movies;
    
    public List<Movie> getMovies(){
        return this.movies;
    }
    
    public void setMovies(List<Movie> movies){
        this.movies = movies;
    }
}
