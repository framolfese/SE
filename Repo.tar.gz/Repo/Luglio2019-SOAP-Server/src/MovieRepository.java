package soap.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MovieRepository {
    private Connection conn;
    
    public MovieRepository() {}
    
    public void setConnection(String pos){
        try{
            try{
                Class.forName("org.sqlite.JDBC");
            }catch(ClassNotFoundException ex) {
                Logger.getLogger(MovieRepository.class.getName()).log(Level.SEVERE, null ,ex);
            }
            conn = DriverManager.getConnection("jdbc:sqlite:"+pos);
        } catch (SQLException ex){
            Logger.getLogger(MovieRepository.class.getName()).log(Level.SEVERE, null ,ex);
        }
    }
    
    public String getDetailOfAMovie(int idMovie){
        PreparedStatement stat = null;
        Movie movie = null;
        Director director = null;
        
        try{
            stat = conn.prepareStatement("select * from movies join directors on directorID = directors.id where movies.ID = ?");
            stat.setString(1, String.valueOf(idMovie));
            
            ResultSet rs = stat.executeQuery();
            if(rs.next()){
                
                movie = new Movie();
                director = new Director();
                
                director.setId(rs.getString("directorID"));
                director.setName(rs.getString("name"));
                director.setYearOfBirth(rs.getString("yearOfBirth"));

                movie.setID(rs.getString("ID"));
                movie.setTitle(rs.getString("title"));
                movie.setYear(rs.getString("year"));
                movie.setDirectorID(rs.getString("directorID"));
                movie.setDirector(director);
                
                Logger.getLogger(MovieRepository.class.getName()).log(Level.INFO, "Accessed Movie: \n" + movie);
            }
        }catch(SQLException ex){
            Logger.getLogger(MovieRepository.class.getName()).log(Level.SEVERE, null ,ex);
        }
        return movie.toString();
    }
    
    public List<Movie> getMovies(){
        PreparedStatement stat = null;
        List<Movie> movies = new ArrayList<Movie>();
        Movie movie;
        Director director;
        
        try{
            stat = conn.prepareStatement("select * from movies join directors on directorID = directors.id");
            ResultSet rs = stat.executeQuery();
            
            while(rs.next()){
                
                movie = new Movie();
                director = new Director();
                
                director.setId(rs.getString("directorID"));
                director.setName(rs.getString("name"));
                director.setYearOfBirth(rs.getString("yearOfBirth"));

                movie.setID(rs.getString("ID"));
                movie.setTitle(rs.getString("title"));
                movie.setYear(rs.getString("year"));
                movie.setDirectorID(rs.getString("directorID"));
                movie.setDirector(director);
                
                movies.add(movie);
                
                Logger.getLogger(MovieRepository.class.getName()).log(Level.INFO, "Accessed Movie: \n" + movie);
            }
        }catch(SQLException ex){
            Logger.getLogger(MovieRepository.class.getName()).log(Level.SEVERE, null ,ex);
        }
        return movies;
    }
}
