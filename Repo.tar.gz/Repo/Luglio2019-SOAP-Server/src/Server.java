package soap.server;

import javax.xml.ws.Endpoint;

public class Server {
    public static void main(String args[]) throws InterruptedException {
        WSImpl implementor = new WSImpl(args[0]);
        String address = "http://localhost:8080/WSInterface";
        Endpoint.publish(address, implementor);
        while(true) {}
    }
}
