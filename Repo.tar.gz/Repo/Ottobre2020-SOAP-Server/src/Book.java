package soap.server;

import java.util.Map;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Book {
    
    private int id;
    private float price;
    private Map<String, String> sellers;
    
    public int getId(){
        return this.id;
    }
    
    public void setId(int id){
        this.id = id;
    }
    
    public float getPrice(){
        return this.price;
    }
    
    public void setPrice(float price){
        this.price = price;
    }
    
    public Map<String, String> getSellers(){
        return this.sellers;
    }
    
    public void setSellers(Map<String, String> sellers){
        this.sellers = sellers;
    }
}
