package soap.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.jws.WebService;

@WebService(endpointInterface = "soap.server.WSInterface")
public class WSImpl implements WSInterface{
    
    private List<Book> booklist = new ArrayList<Book>();

    public WSImpl(){
        Book b1 = new Book();
        Map<String, String> s1 = new HashMap<String, String>();
        s1.put("Seller11", "11/11/2011");
        s1.put("Seller12", "12/11/2011");
        s1.put("Seller13", "13/11/2011");
        b1.setId(1);
        b1.setPrice((float)6.95);
        b1.setSellers(s1);
        
        Book b2 = new Book();
        Map<String, String> s2 = new HashMap<String, String>();
        s2.put("Seller21", "21/11/2012");
        s2.put("Seller22", "22/11/2012");
        s2.put("Seller23", "23/11/2012");
        b2.setId(2);
        b2.setPrice((float)7.95);
        b2.setSellers(s2);
        
        Book b3 = new Book();
        Map<String, String> s3 = new HashMap<String, String>();
        s3.put("Seller31", "01/11/2013");
        s3.put("Seller32", "02/11/2013");
        s3.put("Seller33", "03/11/2013");
        b3.setId(3);
        b3.setPrice((float)8.95);
        b3.setSellers(s3);
        
        booklist.add(b1);
        booklist.add(b2);
        booklist.add(b3);
    }

    @Override
    public String getBookDetails(int bookId) {
        for(int i = 0; i < booklist.size(); i++){
            Book toFind = booklist.get(i);
            if(toFind.getId() == bookId){
                String sellers = "";
                for (Map.Entry<String, String> entry : toFind.getSellers().entrySet()){
                    sellers = sellers + " " + entry.getKey();
                }
                return "price " + String.valueOf(toFind.getPrice()) + " " + "list of sellers" + sellers;
            }
        }
        return "Could not find a book with the given id";
    }

    @Override
    public String getEstimatedDate(int bookId, String seller) {
        for(int i = 0; i < booklist.size(); i++){
            Book toFind = booklist.get(i);
            if(toFind.getId() == bookId){
                return toFind.getSellers().get(seller);
            }
        }
        return "Could not find a valid date for the given book-seller pair";
    }
    
}
