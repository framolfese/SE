package rest.server;

import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

@Path("/books")
@Produces("text/xml")
public class BooksRepository {
    
    private Books books = new Books();

    public BooksRepository(){
        Book b1 = new Book();
        b1.setId(1);
        b1.setTitle("Book1");
        b1.setAuthor("Author1");
        b1.setYear("1991");
        b1.setAuthorYob("1951");
        
        Book b2 = new Book();
        b2.setId(2);
        b2.setTitle("Book2");
        b2.setAuthor("Author2");
        b2.setYear("1992");
        b2.setAuthorYob("1952");
        
        Book b3 = new Book();
        b3.setId(3);
        b3.setTitle("Book3");
        b3.setAuthor("Author3");
        b3.setYear("1993");
        b3.setAuthorYob("1953");

        List<Book> booklist = new ArrayList<Book>();
        booklist.add(b1);
        booklist.add(b2);
        booklist.add(b3);

        books.setBooks(booklist);
    }
    
    @GET
    @Path("{bookId}")
    public Book getBook(@PathParam("bookId") int bookId) {
        return findById(bookId);
    }
    
    @GET
    @Path("")
    public Books getAllBooks(){
        return findAllBooks();
    }
    
    private Book findById(int id) {
        for(int i = 0; i < books.getBooks().size(); i++){
            Book toFind = books.getBooks().get(i);
            if(toFind.getId() == id){
                return toFind;
            }
        }
        return null;
    }
    
    private Books findAllBooks(){
        return books;
    }
}
