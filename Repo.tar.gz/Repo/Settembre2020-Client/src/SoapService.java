package client;

import soap.server.Professor;

public class SoapService {
    
    public static Professor getDetails(String ID){
        soap.server.WSImplService service = new soap.server.WSImplService();
        soap.server.WSInterface port = service.getWSImplPort();
        return port.getDetails(ID);
    }
}