package soap.dbms;
import java.sql.*;

public class DBManager {
    public static void main(String[] args) throws Exception{
        Class.forName("org.sqlite.JDBC");
        Connection conn = DriverManager.getConnection("jdbc:sqlite:" + args[0]);
        Statement stat = conn.createStatement();
        
        if(args[1].equals("create")){
            stat.executeUpdate("drop table if exists movies;");
            stat.executeUpdate("drop table if exists directors;");
            stat.executeUpdate("create table movies (ID, title, year, directorID);");
            stat.executeUpdate("create table directors (id, name, yearOfBirth);");
            
            PreparedStatement prep = conn.prepareStatement("insert into directors values (?, ?, ?);");
            
            prep.setString(1, "1");
            prep.setString(2, "Direttore1");
            prep.setString(3, "1951");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setString(1, "2");
            prep.setString(2, "Direttore2");
            prep.setString(3, "1952");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setString(1, "3");
            prep.setString(2, "Direttore3");
            prep.setString(3, "1953");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setString(1, "4");
            prep.setString(2, "Direttore4");
            prep.setString(3, "1954");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep = conn.prepareStatement("insert into movies values (?, ?, ?, ?);");
            
            prep.setString(1, "1");
            prep.setString(2, "Movie1");
            prep.setString(3, "1961");
            prep.setString(4, "1");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);

            prep.setString(1, "2");
            prep.setString(2, "Movie2");
            prep.setString(3, "1962");
            prep.setString(4, "3");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);

            prep.setString(1, "3");
            prep.setString(2, "Movie3");
            prep.setString(3, "1963");
            prep.setString(4, "4");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);

            prep.setString(1, "4");
            prep.setString(2, "Movie4");
            prep.setString(3, "1964");
            prep.setString(4, "4");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);

            prep.setString(1, "5");
            prep.setString(2, "Movie5");
            prep.setString(3, "1965");
            prep.setString(4, "4");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);

            prep.setString(1, "6");
            prep.setString(2, "Movie6");
            prep.setString(3, "1966");
            prep.setString(4, "1");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);

            prep.setString(1, "7");
            prep.setString(2, "Movie7");
            prep.setString(3, "1967");
            prep.setString(4, "2");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
        }
        else if(args[1].equals("read")){
            ResultSet rs = stat.executeQuery("select * from movies join directors on directorID = directors.id");
            while(rs.next()){
                System.out.println(String.format(""
                        + "Movie id: %s, title: %s, year: %s, directorID: %s,\nDirector id: %s, name: %s, yearOfBirth: %s\n",
                        rs.getString("ID"), rs.getString("title"), rs.getString("year"), rs.getString("directorID"),
                        rs.getString("directorID"), rs.getString("name"), rs.getString("yearOfBirth")
                ));
            }
            rs.close();
        }
        else{
            System.out.println("Comando non riconosciuto.");
        }
        conn.close();
    }
}
