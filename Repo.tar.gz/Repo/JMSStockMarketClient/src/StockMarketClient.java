package it.uniroma1.diag.stockmarket.peer.client;

import it.uniroma1.diag.stockmarket.peer.client.gui.AzioniFrame;

public class StockMarketClient {
	public static void main(String[] args) {
		new AzioniFrame();
	}
}