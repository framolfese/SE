package rest.server;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Book")
public class Book {
    
    private int id;
    private String title;
    private String author;
    private String year;
    private String authorYob;
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }
    
    public void setAuthor(String author) {
        this.author = author;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getAuthorYob() {
        return authorYob;
    }

    public void setAuthorYob(String authorYob) {
        this.authorYob = authorYob;
    }
    
    @Override
    public String toString(){
        return String.format("Book: id %d title %s author %s year %s yearOfBirth %s", 
                this.id, this.title, this.author, this.year, this.authorYob);
    }
}
