package soap.server;

import java.util.HashMap;
import java.util.Map;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Professor {
    private String name;
    private String surname;
    private String course;
    
    private static Map<String, Professor> professors = new HashMap<String, Professor>();
    private static int maxId = -1;
    
    public Professor(){}

    public Professor(String name, String surname, String course) {
        this.name = name;
        this.surname = surname;
        this.course = course;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }
    
    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }
    
    public static Professor getProfessor(String id) {
        return professors.get(id);
    }
    
    public static void insertProfessor(Professor professor) {
        maxId += 1;
        professors.put(String.valueOf(maxId), professor);
    }
}
