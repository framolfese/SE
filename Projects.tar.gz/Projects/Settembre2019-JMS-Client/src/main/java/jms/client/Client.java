package jms.client;

import javax.jms.JMSException;
import javax.naming.NamingException;

public class Client {
    public static void main(String[] args) throws JMSException, NamingException{
        System.out.println("Client start \n");
        FlightsListener f = new FlightsListener();
        f.start();
    }
}
