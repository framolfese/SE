package soap.server;

import java.util.List;
import javax.jws.WebService;

@WebService(endpointInterface = "soap.server.WSInterface")
public class WSImpl implements WSInterface{

    private MovieRepository movierep = new MovieRepository();
    
    public WSImpl(String pos){
        movierep.setConnection(pos);
    }
    
    public String getDetailOfAMovie(int idMovie){
        return movierep.getDetailOfAMovie(idMovie);
    }
    
    public List<Movie> getMovies(){
        return movierep.getMovies();
    }
    
}
