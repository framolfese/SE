package rest.server;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Movie")
public class Movie {
    
    private int id;
    private String title;
    private String year;
    private String directorName;
    private int directorID;
    private Director director;

    public int getDirectorID() {
        return directorID;
    }

    public void setDirectorID(int directorID) {
        this.directorID = directorID;
    }


    public Director getDirector() {
        return director;
    }


    public void setDirector(Director director) {
        this.director = director;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }


    public void setTitle(String title) {
        this.title = title;
    }


    public String getYear() {
        return year;
    }


    public void setYear(String year) {
        this.year = year;
    }


    public String getDirectorName() {
        return directorName;
    }

    public void setDirectorName(String directorName) {
        this.directorName = directorName;
    }
    @Override
    public String toString() {
        return "Movie: " + String.valueOf(id) + " " + title + " " + year + " " + "with director: " + directorName + " " + String.valueOf(directorID) + " " + director.getYearOfBirth();
    }
}
